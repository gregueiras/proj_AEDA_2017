#include "Client.h"

using namespace std;
unsigned int Client::next_id = 1;
// Constructors/Destructors
//  

Client::Client(string name, Address address, unsigned int nif, string pass) {
	this->name = name;
	this->address = address;
	this->nif = nif;
	this->visibility = true;
	this->pass = pass;
	std::vector<Services*> v1;
	this->services = v1;
	this->id = next_id++;
}

Client::Client(string name, Address address, unsigned int nif, string pass,
		unsigned int id) {
	this->name = name;
	this->address = address;
	this->nif = nif;
	this->visibility = true;
	this->pass = pass;
	std::vector<Services*> v1;
	this->services = v1;
	this->id = id;
}

Client::~Client() {
}

//  
// Methods
//  

//bool Client::SupportPayBankTransfer() {
//	return this->sup_pay_bank_transfer;
//}
//
//bool Client::SupportPayCreditCard() {
//	return this->sup_pay_credit_card;
//}
//
//bool Client::SupportPayDebitCard() {
//	return this->sup_pay_debit_card();
//}
//
//bool Client::SupportPayEOM() {
//	return this->sup_pay_eom;
//}

void Client::setVisibility(bool new_var) {
	this->visibility = new_var;
}

void Client::setName(string new_name) {
	this->name = new_name;
}

string Client::getName() {
	return this->name;
}

void Client::setAddress(Address new_add) {
	this->address = new_add;
}

Address Client::getAddress() {
	return this->address;
}

const unsigned int Client::getId() {
	return this->id;
}

void Client::setNif(unsigned int new_nif) {
	this->nif = new_nif;
}

unsigned int Client::getNif() {
	return this->nif;
}

void Client::setServices(vector<Services*> new_serv_vec) {
	this->services = new_serv_vec;
}

vector<Services*> Client::getServices() {
	return this->services;
}

void Client::addServices(Services *new_serv) {
	this->services.push_back(new_serv);
}

Services Client::getServiceById(const unsigned int &id) {
	for (unsigned int i = 0; i < this->getServices().size(); i++) {
		if (this->getServices().at(i)->getId() == id)
			return *this->getServices().at(i);
	}

	return Services(Address(), 0, Address());
}

unsigned int Client::getNextId() {
	return this->next_id;
}

void Client::incNextId() {
	++this->next_id;
}

const unsigned int Client::newId() {
	//	const unsigned int newId = this->getNextId() * 10 + this->client_id;
	//	this->incNextId();
	//	return newId;

	this->incNextId();
	return this->next_id;
}

void Client::setPayment(vector<Payment*> new_pay_vec) {
	this->payments = new_pay_vec;
}

vector<Payment*> Client::getPayment() {
	return this->payments;
}

void Client::addPayment(Payment *new_pay) {
	this->payments.push_back(new_pay);
}

string Client::getInfoDisp() {
	string ret = "Client ID: ";
	ret += std::to_string(this->id);
	ret += "\n";
	ret += "Name: " + this->name + "\n";
	ret += "Address: " + this->getAddress().toStr() + "\n";
	ret += "NIF: " + std::to_string(this->nif) + "\n";
	return ret;

}

void Client::setPass(string new_var) {
	this->pass = new_var;
}

string Client::getPass() {
	return this->pass;
}

bool Client::writeServicesToFile() {
	string file = "client" + to_string(id) + "_services.txt";

	ofstream output(file);

	if (output.is_open()) {

		for (unsigned int i = 0; i < this->services.size(); i++) {

			output << this->services.at(i)->getOriginAddress().getStreet()
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getOriginAddress().getDoor_number())
					<< endl;
			output << this->services.at(i)->getOriginAddress().getCity()
					<< endl;
			output << this->services.at(i)->getOriginAddress().getCounty()
					<< endl;
			output << this->services.at(i)->getOriginAddress().getCountry()
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getOriginAddress().getCoordinates().getLatitude())
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getOriginAddress().getCoordinates().getLongitude())
					<< endl << endl;

			output << this->services.at(i)->getDestinationAddress().getStreet()
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getDestinationAddress().getDoor_number())
					<< endl;
			output << this->services.at(i)->getDestinationAddress().getCity()
					<< endl;
			output << this->services.at(i)->getDestinationAddress().getCounty()
					<< endl;
			output << this->services.at(i)->getDestinationAddress().getCountry()
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getDestinationAddress().getCoordinates().getLatitude())
					<< endl;
			output
					<< to_string(
							this->services.at(i)->getDestinationAddress().getCoordinates().getLongitude())
					<< endl << endl;

			output
					<< this->services.at(i)->getPackaging().getStart_date().toStr()
					<< endl;
			output
					<< this->services.at(i)->getPackaging().getStart_hour().toStr()
					<< endl;

			output
					<< to_string(
							this->services.at(i)->getDelivery().getStart_date()
									- this->services.at(i)->getShipping().getArrival_date())
					<< endl;

			if ((i + 1) != this->services.size())
				output << this->services.at(i)->getVolume() << endl;
			else
				output << this->services.at(i)->getVolume();

		}

	} else
		return false;

	output.close();
	return true;
}

bool Client::writePaymentsToFile() {
	string file = "client" + to_string(id) + "_payments.txt";

	ofstream output(file);

	if (output.is_open()) {

		for (unsigned int i = 0; i < this->payments.size(); i++) {
			//Pay Type
			output << this->getPayment().at(i)->getPayType() << endl << endl;
			//Value
			output << to_string(this->getPayment().at(i)->getValue()) << endl
					<< endl;
			//Due
			output << to_string((int) this->getPayment().at(i)->getDue())
					<< endl << endl;
			//Due Date & Hour
			output << this->getPayment().at(i)->getDueDate().toStr() << endl;
			output << this->getPayment().at(i)->getDueHour().toStr() << endl
					<< endl;
		}

	} else
		return false;

	output.close();
	return true;
}

bool Client::writeClientToFile() {
	string file = "client" + to_string(id) + ".txt";

	ofstream output(file);

	if (output.is_open()) {

		for (unsigned int i = 0; i < this->payments.size(); i++) {
			//Client Type
			output << this->getClientType() << endl << endl;
			//Name
			output << this->getName() << endl << endl;
			//Address info
			output << this->getAddress().getStreet() << endl;
			output << to_string(this->getAddress().getDoor_number()) << endl;
			output << this->getAddress().getCity() << endl;
			output << this->getAddress().getCounty() << endl;
			output << this->getAddress().getCountry() << endl;
			output
					<< to_string(
							this->getAddress().getCoordinates().getLatitude())
					<< endl;
			output
					<< to_string(
							this->getAddress().getCoordinates().getLongitude())
					<< endl << endl;
			//nif
			output << to_string(this->getNif()) << endl << endl;
			//pass	
			output << this->getPass() << endl << endl;
		}

	} else
		return false;

	output.close();
	return true;
}

