/*
 * ChangeServiceView.h
 *
 *  Created on: 15/11/2017
 *      Author: jotaa
 */

#ifndef SRC_VIEW_HEADERS_CHANGESERVICEVIEW_H_
#define SRC_VIEW_HEADERS_CHANGESERVICEVIEW_H_

#include "Utilities.h"

class ChangeServiceView {
private:
	Utilities *u; 
public:
	ChangeServiceView();
	virtual ~ChangeServiceView();
};

#endif /* SRC_VIEW_HEADERS_CHANGESERVICEVIEW_H_ */
