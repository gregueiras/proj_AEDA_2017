/*
 * RemoveServiceView.cpp
 *
 *  Created on: 15/11/2017
 *      Author: jotaa
 */

#include "RemoveServiceView.h"

RemoveServiceView::RemoveServiceView() {
	// TODO Auto-generated constructor stub

}

RemoveServiceView::~RemoveServiceView() {
	// TODO Auto-generated destructor stub
}

