/*
 * RemoveServiceView.h
 *
 *  Created on: 15/11/2017
 *      Author: jotaa
 */

#ifndef SRC_VIEW_HEADERS_REMOVESERVICEVIEW_H_
#define SRC_VIEW_HEADERS_REMOVESERVICEVIEW_H_

class RemoveServiceView {
public:
	RemoveServiceView();
	virtual ~RemoveServiceView();
};

#endif /* SRC_VIEW_HEADERS_REMOVESERVICEVIEW_H_ */
