var searchData=
[
  ['addclient',['addClient',['../class_company.html#ada99adc3cba705135cdc8f0fae3066f3',1,'Company']]],
  ['addpayment',['addPayment',['../class_client.html#a3cb0725d3681860ebe499c141158bbec',1,'Client::addPayment()'],['../class_company.html#a076efd42e18abf25e1ec5c95cdbdc1ff',1,'Company::addPayment()']]],
  ['address',['Address',['../class_address.html#a63f910c09d93bdd16d3744e47d13dc0e',1,'Address']]],
  ['addservice',['addService',['../class_company.html#ab52ffaac5d04f54bbbad8c241993a85d',1,'Company']]],
  ['addservices',['addServices',['../class_client.html#ae37dda5b4861d8f8cfe7fb0578010493',1,'Client']]],
  ['auxcalctimepackaging',['auxCalcTimePackaging',['../class_services.html#a1a74141e5d1de6e61c067438ab917a94',1,'Services']]],
  ['auxcalctimeshipping',['auxCalcTimeShipping',['../class_services.html#aa8aac66bcc1ee54ab66bce17ca248199',1,'Services']]]
];
