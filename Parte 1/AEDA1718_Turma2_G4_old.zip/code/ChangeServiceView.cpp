/*
 * ChangeServiceView.cpp
 *
 *  Created on: 15/11/2017
 *      Author: jotaa
 */

#include "ChangeServiceView.h"

ChangeServiceView::ChangeServiceView() {
	u = new Utilities(); 
}

ChangeServiceView::~ChangeServiceView() {
	// TODO Auto-generated destructor stub
}

