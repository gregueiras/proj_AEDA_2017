var searchData=
[
  ['expectable_5fday',['expectable_day',['../class_vehicle.html#aed17ccf83395136b08d99d920dec86e5',1,'Vehicle']]],
  ['expectable_5ftime',['expectable_time',['../class_vehicle.html#a5b3afbff89a687ea93b9cc79bcd42578',1,'Vehicle']]]
];
