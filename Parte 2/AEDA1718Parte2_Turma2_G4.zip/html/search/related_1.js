var searchData=
[
  ['clientrecord',['ClientRecord',['../class_client.html#ac0678cef7b54142d1212e0ba63c9f97d',1,'Client']]]
];
