var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw~",
  1: "abcdefghilnprsuv",
  2: "s",
  3: "abcdefghlmnprsuv",
  4: "abcdefghilmnoprstuvw~",
  5: "abeimp",
  6: "h",
  7: "bcos",
  8: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "related",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Friends",
  8: "Macros"
};

