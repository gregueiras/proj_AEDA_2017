var searchData=
[
  ['unregistered',['Unregistered',['../class_unregistered.html',1,'Unregistered'],['../class_unregistered.html#a6d09ff9035581ae58850076280373d17',1,'Unregistered::Unregistered(string name, Address address, unsigned int nif)'],['../class_unregistered.html#a89ad7e31ab3fbd6f1702f4dbc427ee06',1,'Unregistered::Unregistered(string name, Address address, unsigned int nif, unsigned int id)']]],
  ['unregistered_2ecpp',['Unregistered.cpp',['../_unregistered_8cpp.html',1,'']]],
  ['unregistered_2eh',['Unregistered.h',['../_unregistered_8h.html',1,'']]],
  ['updateavailablevehicles',['updateAvailableVehicles',['../class_company.html#a931cd0ff12fec358a44235218a54706e',1,'Company']]],
  ['usermenucontroller',['UserMenuController',['../class_user_menu_controller.html',1,'UserMenuController'],['../class_user_menu_controller.html#a23bced0fd224eb6e2ea6c1b7905d78bd',1,'UserMenuController::UserMenuController()']]],
  ['usermenucontroller_2ecpp',['UserMenuController.cpp',['../_user_menu_controller_8cpp.html',1,'']]],
  ['usermenucontroller_2eh',['UserMenuController.h',['../_user_menu_controller_8h.html',1,'']]],
  ['usermenuview',['UserMenuView',['../class_user_menu_view.html',1,'UserMenuView'],['../class_user_menu_view.html#a9ae7ab7cfb97425aaff225061917e05c',1,'UserMenuView::UserMenuView()']]],
  ['usermenuview_2ecpp',['UserMenuView.cpp',['../_user_menu_view_8cpp.html',1,'']]],
  ['usermenuview_2eh',['UserMenuView.h',['../_user_menu_view_8h.html',1,'']]],
  ['utilities',['Utilities',['../class_utilities.html',1,'Utilities'],['../class_utilities.html#ab1676c9ce35cf347a73d16f1094e1271',1,'Utilities::Utilities()']]],
  ['utilities_2ecpp',['Utilities.cpp',['../_utilities_8cpp.html',1,'']]],
  ['utilities_2eh',['Utilities.h',['../_utilities_8h.html',1,'']]]
];
