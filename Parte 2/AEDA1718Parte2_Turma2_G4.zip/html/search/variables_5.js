var searchData=
[
  ['plate',['plate',['../class_vehicle.html#ab59f22f161826f4140185a14b59a0118',1,'Vehicle']]]
];
