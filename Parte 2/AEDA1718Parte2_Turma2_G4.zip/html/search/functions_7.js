var searchData=
[
  ['hour',['Hour',['../class_hour.html#a381ac90e22c62ecb6cd8a7c78c2debfc',1,'Hour::Hour(unsigned int h, unsigned int m)'],['../class_hour.html#a7519964d5f45cdbffb5e0160f880d40a',1,'Hour::Hour(unsigned int h, unsigned int m, bool b)'],['../class_hour.html#a57b604e71195671d96ef6b8e7b819a71',1,'Hour::Hour()']]],
  ['hourinvalidhour',['HourInvalidHour',['../class_hour_invalid_hour.html#a6251afd6e5393d510d44282838f92a85',1,'HourInvalidHour']]],
  ['hourinvalidminute',['HourInvalidMinute',['../class_hour_invalid_minute.html#ab7b5c5f08c16964c80e30fcc4fa7b46b',1,'HourInvalidMinute']]]
];
