var searchData=
[
  ['inactiveclientshash',['inactiveClientsHash',['../structinactive_clients_hash.html',1,'']]]
];
